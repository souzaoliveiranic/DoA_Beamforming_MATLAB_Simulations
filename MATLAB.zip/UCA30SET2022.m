%--------------------------------------------------------------------
% MiniDSP  UMA-8 v2
% USB Microphone Array with Embedded DSP
% Using UMA-8 with Matlab: 
% https://www.minidsp.com/applications/usb-mic-array/uma-8-16-matlab
%--------------------------------------------------------------------
clear; close all; clc;
% Gravando nrsegs segundos de audio:
nrsegs=5;
% Defining recording interface using the device reader object
% Notice how the UMA-8/16 will be discovered as "miniDSP ASIO Driver". 
% Make sure that you use ASIO for your definition as standard WDM 
% recording object won't be working. 
% EM OUTRAS PALAVRAS: INSTALAR O DEVICE DRIVER 
%                     (em micArray_VF_v1.2_drv_4_67.zip)
fs = 48000;
audioFrameLength = nrsegs*fs; % srsegs segundos de sinal
deviceReader = audioDeviceReader(...
  'Device', 'miniDSP ASIO Driver',...
  'Driver', 'ASIO', ...
  'SampleRate', fs, ...
  'NumChannels', 7 ,... 
  'OutputDataType','double',...
  'SamplesPerFrame', audioFrameLength);
% That's all, you now have real time audio within your environment! 
% The returned array data (matrix X) is of size (fs*NrSegundos) x (NrMICs)
X = step(deviceReader); X=X/max(max(abs(X)));
t=(0:(length(X(:,1))-1))/fs;
Deltat=t(end);
subplot(7,1,1); plot(t,X(:,1)); axis([0 Deltat -1  1])
subplot(7,1,2); plot(t,X(:,2)); axis([0 Deltat -1  1])
subplot(7,1,3); plot(t,X(:,3)); axis([0 Deltat -1  1])
subplot(7,1,4); plot(t,X(:,4)); axis([0 Deltat -1  1])
subplot(7,1,5); plot(t,X(:,5)); axis([0 Deltat -1  1])
subplot(7,1,6); plot(t,X(:,6)); axis([0 Deltat -1  1])
subplot(7,1,7); plot(t,X(:,7)); axis([0 Deltat -1  1])
%return
% audiowrite('AudioUMA8File01.wav',X,fs)
% Observa��es sobre o sinal gravado:
fs = 48000;
t=(0:1/fs:nrsegs).';
temp=23; % graus Celsius
vsom=20.055*sqrt(temp+273.15);
r = 0.0430;
M=6; % 6 mics circle (mic 0 centered, not in the array)
%--------------------------------------------
% Coordenadas (x,y,z em metro) dos microfones
%--------------------------------------------
%p0= [0        0      0].';
%p1= [0        0.0430 0].';
%p2= [0.0372   0.0215 0].';
%p3= [0.0372  -0.0215 0].';
%p4= [0       -0.0430 0].';
%p5= [-0.0372 -0.0215 0].';
%p6= [-0.0372  0.0215 0].';
positions=[r*sin(2*pi*(0:(M-1))/M) % r*sin(2*pi*(m-1)/M), 1 <= m <= M
           r*cos(2*pi*(0:(M-1))/M) % r*cos(2*pi*(m-1)/M), 1 <= m <= M
           zeros(1,M)];
p1=positions(:,1);        p2=positions(:,2);       
p3=positions(:,3);        p4=positions(:,4);       
p5=positions(:,5);        p6=positions(:,6);   
figure
plot(p1(1),p1(2),'bx','linewidth',2); text(p1(1)+0.002,p1(2),'MIC 1')
hold on
plot(p2(1),p2(2),'bx','linewidth',2); text(p2(1)+0.002,p2(2),'MIC 2')
plot(p3(1),p3(2),'bx','linewidth',2); text(p3(1)+0.002,p3(2),'MIC 3')
plot(p4(1),p4(2),'bx','linewidth',2); text(p4(1)+0.002,p4(2),'MIC 4')
plot(p5(1),p5(2),'bx','linewidth',2); text(p5(1)+0.002,p5(2),'MIC 5')
plot(p6(1),p6(2),'bx','linewidth',2); text(p6(1)+0.002,p2(2),'MIC 6')
axis equal
line([-0.45 0.45]'/10,[0 0]'/10) % eixo x
line([0 0]'/10,[-0.45 0.45]'/10) % eixo y
return

%--------------------------------------------------------------------------
% Refs (Matlab): 
% https://www.mathworks.com/help/audio/examples/live-direction-of-arrival-estimation-with-a-linear-microphone-array.html 
% https://www.mathworks.com/help/audio/gs/real-time-audio-in-matlab.html
% beamforming_demo.m by Florent (miniDSP Forum Flo96)
%--------------------------------------------------------------------------

