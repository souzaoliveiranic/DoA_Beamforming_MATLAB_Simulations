%% DOA wideband coerente (AMI mod.) + MUSIC para DUAS FONTES em UCA (8 mics)
clear; clc; close all;

%% ===================== PARÂMETROS GERAIS =====================
c       = 343;                % velocidade do som (m/s)
fs      = 8e3;               % taxa de amostragem (Hz) (baixa p/ manter kr<1)
M       = 8;                  % nº de microfones (UCA)
r       = 0.043;              % raio do UCA (m)
theta_deg = 205;                % DOA (azimute verdadeiro, graus)
Lsrc    = 1;                  % nº de fontes
SNR_dB  = 10;                 % SNR por sensor (dB)

% Banda útil (garantir kr < 1): k*r = 2*pi*f*r/c
fmin = 300; 
fmax = 1200;
J   = 30;                              % nº de bins úteis (ajustável)

Q       = 8;                  % nº de janelas
N       = 4096;               % amostras por janela
hop     = N;                  % sem overlap (simples)
Nfft    = N;                  % FFT sem zero-padding (ajuste se quiser)
w       = hann(N);            % janela temporal

%% ===================== ARRANJO (UCA) =========================
m_idx = (0:M-1).';
psi_m = 2*pi*m_idx/M;         % ângulo de cada mic
theta_rad  = deg2rad(theta_deg);     % DOA verdadeiro (rad)

% Atrasos (onda plana no plano do array; referência no centro):
% tau_m = (r/c)*cos(theta_rad - psi_m)
tau1 = -(r/c)*cos(theta_rad - psi_m);   % em segundos (pode ser fracionário)

%% ===================== GERAÇÃO DA FONTE (ÁUDIO) ==============
% Fonte wideband: ruído branco 
Ttotal = Q*N;                          % total de amostras
s1 = randn(Ttotal,1);  s1 = s1/rms(s1);

%% ===================== SINAIS NOS MICROFONES (delayseq) ======
% Modelagem direta no tempo por atraso fracionário de cada mic.
x = zeros(Ttotal, M);
for m = 1:M
    xm1 = delayseq(s1, tau1(m), fs);
    x(:,m) = xm1;
end

% Adiciona ruído em cada mic com SNR alvo
for m = 1:M
    Ps = rms(x(:,m))^2;
    Pn = Ps / (10^(SNR_dB/10));
    x(:,m) = x(:,m) + sqrt(Pn)*randn(Ttotal,1);
end

% PLOT: sinais temporais em cada microfone 
Ns_plot = min(2000, size(x,1));  tplot = (0:Ns_plot-1)/fs;
figure('Name','Sinais por microfone');
tiledlayout(M,1,'TileSpacing','compact','Padding','compact');
for m = 1:M
    nexttile;
    plot(tplot, x(1:Ns_plot,m));
    grid on; ylabel(sprintf('Mic %d', m));
    if m==1, title('Sinais recebidos (trecho no tempo)'); end
    if m==M, xlabel('Tempo (s)'); end
end

%% ===================== FILTRAGEM DO SINAL ======
% Fonte wideband: ruído branco filtrado na banda [fmin,fmax]
Bfir = fir1(256, [fmin fmax]*(2/fs), 'bandpass', hamming(257));
s1 = filter(Bfir,1,s1);

% PLOT: resposta em frequência do FIR (Hamming)
nfft_fir = 4096;
[H,wf] = freqz(Bfir,1,nfft_fir,fs);    % H(f) em Hz
figure('Name','FIR - Resposta em frequência');
plot(wf, 20*log10(abs(H)+eps), 'LineWidth',1.2); grid on;
ylabel('|H(f)| (dB)'); xlim([0 fs/2]);
title(sprintf('FIR passa-faixa (ordem %d) – Hamming', numel(Bfir)-1));
hold on; yL = ylim;
plot([fmin fmin], yL,'r--'); plot([fmax fmax], yL,'r--');
legend('Magnitude','f_{min}','f_{max}','Location','best');

%% ===================== FFT POR JANELA/MIC ===================
% Organiza Xqmk: Q x M x Nfft
Xqmk = zeros(Q, M, Nfft);
t0 = 1;
for q = 1:Q
    seg = x(t0:t0+N-1, :);                  % N x M
    segw = seg .* w;                        % janela por coluna
    Xblk = fft(segw, Nfft, 1);              % Nfft x M (FFT em cada coluna)
    Xqmk(q,:,:) = Xblk.';                   % armazenar como M x Nfft
    t0 = t0 + hop;
end

%% ===================== SELEÇÃO DE BINS MAIS ENERGÉTICOS ======
f = (0:Nfft-1)*(fs/Nfft);
use = find(f>=fmin & f<=fmax);

% Energia média por bin na banda (somando sobre sensores e snapshots)
E = zeros(1, numel(use));
for q = 1:Q
    Xband = squeeze(Xqmk(q,:,use));   % M x |use|
    E = E + sum(abs(Xband).^2, 1);
end

[~,ord]  = sort(E, 'descend');
ord      = ord(1:J);
idx_bins = use(ord);                    % pega os J bins mais energéticos
fsel     = f(idx_bins);                  % frequências selecionadas
f0       = median(fsel);               % freq central p/ foco coerente
all_idx    = 1:Nfft;

% Extrair X(q)(k_j) como Q x M x J
XQ = zeros(Q, M, J);
for q = 1:Q
    XQ(q,:,:) = squeeze(Xqmk(q,:,idx_bins));
end


% PLOT: energia por bin e bins selecionados
f_band = f(use); % vetor de frequências na banda
E_norm = E / max(E+eps);
figure('Name','Energia por bin + seleção');
plot(f_band, 10*log10(E_norm + eps), 'LineWidth',1.2); grid on;
xlabel('Frequência (Hz)'); ylabel('Energia média por bin (dB, norm.)');
title('Energia por bin (banda útil) + bins selecionados');
hold on;

% marcar bins escolhidos
stem(fsel, 10*log10(E(ord)/max(E)+eps), 'r.', 'LineWidth',1.5);
yL = ylim;
plot([fmin fmin], yL, 'k--'); 
plot([fmax fmax], yL, 'k--');
legend('Energia por bin','Bins selecionados','f_{min}/f_{max}','Location','best');

% FFT do sinal de entrada 
Ns_view = min(N, numel(s1));
S_view  = fft(s1(1:Ns_view) .* hann(Ns_view), Ns_view);
f_view  = (0:Ns_view-1)*(fs/Ns_view);
figure('Name','FFT de s1 (trecho)');
plot(f_view, 20*log10(abs(S_view)/max(abs(S_view))+eps),'LineWidth',1.2);
grid on; xlim([0 fs/2]);
xlabel('Frequência (Hz)'); ylabel('|S_1(f)| (dB, norm.)');
title('FFT do sinal de entrada s1 (trecho)');
hold on; yL = ylim;
plot([fmin fmin], yL, 'r--'); plot([fmax fmax], yL, 'r--');
legend('S_1(f)','f_{min}/f_{max}','Location','best');



%% ===================== COVARIÂNCIAS POR BIN ===================
Rj = cell(J,1);
for jj = 1:J
    Xkj = squeeze(XQ(:, :, jj));      % Q x M
    Rj{jj} = (Xkj.') * conj(Xkj) / Q; % M x M
end

%% ===================== MATRIZ DE FOCO (AMI RÁPIDO) ===========
% T_j[r,c] = (1/M) * sum_{n=-N..N} (f0/fj)^n * W^{ n*(r-c) },  W = exp(j*2*pi/M)
use_fast_focus = true;           % rápida (aprox. kr<1)
Ntrunc = floor((M-1)/2);         % truncamento (para M=8 -> N=3)
nvec   = (-Ntrunc:Ntrunc).';
W      = exp(1j*2*pi/M);
mr     = (0:M-1).';
mc     = (0:M-1);
Drc    = mr - mc;                % MxM diferenças de índice

Tj = cell(J,1);
for jj = 1:J
    fj = fsel(jj);
    if use_fast_focus
        pow = (f0/fj).^nvec;     % (2N+1)x1
        T   = zeros(M,M);
        for idx = 1:numel(nvec)
            T = T + pow(idx) * (W.^(nvec(idx)*Drc));
        end
        Tj{jj} = (1/M) * T;
    else
        % --------- (opcional) versão exata com Bessel ----------
        k0 = 2*pi*f0/c;  kj = 2*pi*fj/c;
        F  = (1/sqrt(M)) * exp(-1j*2*pi/M * (mr*mc));
        nB = (-Ntrunc:Ntrunc).';
        J0 = besselj(nB, k0*r);
        Jj = besselj(nB, kj*r);
        D  = diag(J0 ./ Jj);
        Dfull = zeros(M,M);
        i0    = floor((M - numel(nB))/2) + 1;
        i1    = i0 + numel(nB) - 1;
        Dfull(i0:i1, i0:i1) = D;
        Tj{jj} = F * Dfull * F';
        % -------------------------------------------------------
    end
end

%% ===================== SOMA COERENTE (R̃) =====================
Rtil = zeros(M,M);
for jj = 1:J
    T = Tj{jj};
    Rtil = Rtil + T * Rj{jj} * T';
end
Rtil = (Rtil + Rtil')/2;          % força hermiticidade

% PLOT: autovalores de R̃ (checar #fontes)
lam = sort(real(eig(Rtil)),'descend');
figure('Name','Autovalores de R̃');
stem(1:numel(lam), lam, 'filled'); grid on;
xlabel('Índice'); ylabel('Autovalor');
title('Autovalores da covariância focada ~R');

%% ===================== MUSIC NARROWBAND EM f0 =================
L = Lsrc;                         % nº de fontes (assumido)
[U,S] = eig(Rtil);
[~,ordEV] = sort(real(diag(S)),'ascend');
UN = U(:, ordEV(1:M-L));          % subespaço do ruído

k0 = 2*pi*f0/c;
phi_grid = linspace(0, 2*pi, 1440);   % grade fina
P = zeros(size(phi_grid));
for ii = 1:numel(phi_grid)
    phi = phi_grid(ii);
    a = exp(1j * k0 * r * cos(phi - psi_m));   % Mx1
    P(ii) = 1 ./ real(a'*(UN*UN')*a);
end

[~,imax] = max(P);
phi_hat = phi_grid(imax);
phi_hat_deg = rad2deg(mod(phi_hat, 2*pi));
%if phi_hat_deg > 180, phi_hat_deg = phi_hat_deg - 360; end

%% ===================== RESULTADOS & PLOTS =====================
fprintf('DOA verdadeiro: %6.2f° | DOA estimado (MUSIC @ f0=%.1f Hz): %6.2f°\n', ...
        theta_deg, f0, phi_hat_deg);

figure('Name','MUSIC'); 
plot(rad2deg(phi_grid), 10*log10(P/max(P)),'LineWidth',1.5);
grid on; xlim([0 360]); ylim([-60 0]); 
xlabel('Azimute (graus)'); ylabel('Espectro MUSIC (dB, norm.)');
title(sprintf('MUSIC wideband coerente (UCA M=%d, f_0=%.1f Hz, SNR=%g dB)', M, f0, SNR_dB));
hold on; 
yL = ylim;
plot([theta_deg theta_deg], yL, 'k--', 'LineWidth',1);
plot([phi_hat_deg phi_hat_deg], yL, 'r-.', 'LineWidth',1);
legend('P(\phi)','Verdadeiro','Estimado','Location','best');

% Checagem de kr na banda
kr_min = 2*pi*fmin*r/c;
kr_max = 2*pi*fmax*r/c;
fprintf('Checagem kr:  min = %.3f  |  max = %.3f   (usar foco rápido se kr<1)\n', kr_min, kr_max);

%PLOT: kr em função da frequência ------------------
fgrid = linspace(0, fs/2, 1000);
kr    = 2*pi*fgrid*r/c;
figure('Name','kr vs frequência');
plot(fgrid, kr, 'LineWidth',1.2); grid on;
xlabel('Frequência (Hz)'); ylabel('kr');
title('Parâmetro kr vs. frequência');
hold on; yL = ylim;
plot([fmin fmin], yL,'r--'); plot([fmax fmax], yL,'r--');
plot([0 fs/2],[1 1],'k:');
legend('kr','f_{min}','f_{max}','kr=1','Location','best');


